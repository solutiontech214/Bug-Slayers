package com.controller;

import com.service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/logs")
public class LogController {

    private final LogService logService;

    // Constructor Injection (best practice)
    @Autowired
    public LogController(LogService logService) {
        this.logService = logService;
    }

    /**
     * 🔥 Receive logs from SDK (batch supported)
     */
    @PostMapping
    public String receiveLogs(
            @RequestBody List<Map<String, Object>> logs,
            @RequestHeader(value = "Authorization", required = false) String apiKey
    ) {

        if (logs == null || logs.isEmpty()) {
            return "No logs received";
        }

        // 🔥 Basic validation
        if (apiKey == null || apiKey.isEmpty()) {
            return "Missing API Key";
        }

        try {
            logService.processLogs(logs, apiKey);
            return "Logs processed successfully";

        } catch (Exception e) {
            System.out.println("Error processing logs");
            return "Internal Server Error";
        }
    }

    /**
     * 🔹 Health check API
     */
    @GetMapping("/health")
    public String healthCheck() {
        return "Backend is running";
    }
}