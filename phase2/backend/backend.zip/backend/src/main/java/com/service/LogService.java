package com.service;

import com.model.LogEntity;
import com.repository.LogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class LogService {

    private final LogRepository logRepository;

    @Autowired
    public LogService(LogRepository logRepository) {
        this.logRepository = logRepository;
    }

    /**
     * 🔥 Process logs and save to DB
     */
    public void processLogs(List<Map<String, Object>> logs, String apiKey) {

        System.out.println("\n🔥 Saving Logs to Database...");
        System.out.println("API Key: " + apiKey);

        for (Map<String, Object> log : logs) {

            try {
                String level = (String) log.get("level");
                String message = (String) log.get("message");

                Map<String, Object> metadata = (Map<String, Object>) log.get("metadata");

                String projectId = metadata != null ? (String) metadata.get("projectId") : null;
                String moduleId = metadata != null ? (String) metadata.get("moduleId") : null;
                String subModuleId = metadata != null ? (String) metadata.get("subModuleId") : null;
                String environment = metadata != null ? (String) metadata.get("environment") : null;

                Long timestamp = null;
                if (metadata != null && metadata.get("timestamp") != null) {
                    timestamp = ((Number) metadata.get("timestamp")).longValue();
                }

                String stackTrace = (String) log.get("stackTrace");

                // 🔥 Create Entity
                LogEntity entity = new LogEntity(
                        apiKey,
                        projectId,
                        moduleId,
                        subModuleId,
                        environment,
                        level,
                        message,
                        stackTrace,
                        timestamp,
                        null // extra (we can add later)
                );

                // 🔥 SAVE TO DB
                logRepository.save(entity);

                System.out.println("✅ Saved log: " + message);

            } catch (Exception e) {
                System.out.println("❌ Failed to save log");
            }
        }

        System.out.println("🚀 Batch saved successfully\n");
    }
}